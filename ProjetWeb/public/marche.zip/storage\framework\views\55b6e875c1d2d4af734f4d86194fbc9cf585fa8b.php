<?php $__env->startSection('content'); ?>
<!-- Start of event section -->
<section id="event">
    <div class="event_section container">
        <h3 class="title_section">Création d'evènement</h3>
        <div class="row">
            <div class="col-12">
                <?php echo Form::open(['action' => 'EventsController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

                    <div class="form-group">
                        <?php echo e(Form::label('title', 'Titre')); ?>

                        <?php echo e(Form::text('name', '', [
                        'class' => 'form-control',
                        'placeholder' => 'Nom de l\'evènement'])); ?>

                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('price', 'Prix')); ?>

                        <?php echo e(Form::number('price', '', [ 'class' => 'form-control' ])); ?>

                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('description', 'Description')); ?>

                        <?php echo e(Form::textarea('description', '', [
                        'class' => 'form-control',
                        'placeholder' => 'Description de l\'evènement'
                    ])); ?>

                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('max_participants', 'Nombre de place disponible')); ?>

                        <?php echo e(Form::number('max_participants', '', [ 'class' => 'form-control' ])); ?>

                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('start_date', 'Date de début')); ?>

                        <?php echo e(Form::date('start_date', \Carbon\Carbon::now())); ?>

                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('end_date', 'Date de fin')); ?>

                        <?php echo e(Form::date('end_date', \Carbon\Carbon::now())); ?>

                    </div>
                    <div class="form-group">
                        <?php echo e(Form::file('event_image')); ?>

                    </div>
                    <?php echo e(Form::submit('Submit', ['class' => 'btn btn-primary'])); ?>

                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
</section>
<!-- End of event section -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>