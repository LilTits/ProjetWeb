<?php $__env->startSection('content'); ?>
<?php if(auth()->guard()->check()): ?>
<!-- Start of idea section -->
<section id="idea">
    <div class="idea_section container">
        <h3 class="title_section">Boite à idées</h3>
        <div class="row">
            <div class="col-12">
                <?php echo Form::open(['action' => 'IdeasController@store', 'method' => 'POST']); ?>

                    <div class="form-group">
                        <?php echo e(Form::label('title', 'Titre')); ?>

                        <?php echo e(Form::text('title', '', [
                        'class' => 'form-control',
                        'placeholder' => 'Nom de la proposition'])); ?>

                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('description', 'Description')); ?>

                        <?php echo e(Form::textarea('description', '', [
                        'class' => 'form-control',
                        'placeholder' => 'Description de la proposition'
                    ])); ?>

                    </div>
                    <?php echo e(Form::submit('Submit', ['class' => 'btn btn-primary'])); ?>

                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
</section>

<?php endif; ?>
<?php if(auth()->guard()->guest()): ?>

<div class="d-flex justify-content-center"><?php echo $__env->make('auth.login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></div>
<?php endif; ?>
<!-- End of idea section -->
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>