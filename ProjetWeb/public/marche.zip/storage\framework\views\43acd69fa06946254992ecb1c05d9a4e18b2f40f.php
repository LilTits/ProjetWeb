
<p>Bonjour, il semblerait que certaines photos, commentaires ou manifestations ne soient pas corrects, pourriez-vous vous en occuper. Je suis <?php echo e(Auth::user()->first_name); ?></p>
