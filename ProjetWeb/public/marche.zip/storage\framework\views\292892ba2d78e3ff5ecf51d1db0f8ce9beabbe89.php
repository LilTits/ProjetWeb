<?php $__env->startSection('content'); ?>
<!-- Start of idea section -->
<section id="idea">
    <div class="idea_section container">
        <a href="/ideas" class="btn btn-default">Retour en arrière</a>
        <div class="col-12 item_idea">
            <img src="iphonex.png" class="card-img-top img-thumbnail image_idea" alt="idea">
            <small class="card-body">
                <h5 class="card-title"><?php echo e($idea->title); ?></h5>
                <h6 class="price"><?php echo e($idea->price); ?></h6>
                <p class="card-text"><?php echo e($idea->description); ?></p>
            </small>
        </div>
        <hr>
        <small>Ajouté le <?php echo e($idea->created_at); ?></small>
        <hr>
        <a href="/ideas/<?php echo e($idea->idea_id); ?>/edit" class="btn">Edition</a>
        <?php echo Form::open(['action' => ['IdeasController@destroy', $idea->idea_id], 'method' => 'POST']); ?>

            <?php echo e(Form::hidden('_method', 'DELETE')); ?>

            <?php echo e(Form::submit('Suppression', ['class' => 'btn btn-danger'])); ?>

        <?php echo Form::close(); ?>

        <hr>
        <div class="comment_section container">
            <a href="/comments" class="btn btn-default">Retour en arrière</a>
            <div class="col-12 item_comment">
                <small class="card-body">
                    <p class="card-text"><?php echo e($comment->description); ?></p>
                </small>
            </div>
            <hr>
            <small>Ajouté le <?php echo e($comment->created_at); ?></small>
            <hr>
            <a href="/comments/<?php echo e($comment->comment_id); ?>/edit" class="btn">Edition</a>
            <?php echo Form::open(['action' => ['CommentsController@destroy', $comment->id], 'method' => 'POST']); ?>

                <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                <?php echo e(Form::submit('Suppression', ['class' => 'btn btn-danger'])); ?>

            <?php echo Form::close(); ?>

        </div>
    </div>
</section>
<!-- End of idea section -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>