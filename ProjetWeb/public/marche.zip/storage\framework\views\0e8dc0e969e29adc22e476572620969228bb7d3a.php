<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    </head>
    <body>
        <div id="app">
            <example></example><!--ddededede-->
        </div>
        <script type="text/javascript" src="<?php echo e(asset('js/app.js')); ?>"></script>
    </body>
</html>

