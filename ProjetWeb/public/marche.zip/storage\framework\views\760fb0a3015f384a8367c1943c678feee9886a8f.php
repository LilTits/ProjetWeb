<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <script src="<?php echo e(asset('js/app.js')); ?>"></script>
        <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
        <title>BDE CESI La Rochelle</title>
    </head>
    <body>

        <!--Rajouter if connecter-->
        
        <?php echo $__env->make('pages.loginRe', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        
        <?php echo $__env->make('inc.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        
        <?php echo $__env->make('inc.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
        
        <?php echo $__env->make('inc.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        
        <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    </body>
</html>