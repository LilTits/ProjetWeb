<!-- Début footer -->
<footer id="footer">
    <div id="term" class="container">
        <h5><a href="/legale">Mentions Légales & Politique de Protection des Données Personnelles & Conditions générales de vente</a></h5>
    </div>
    <div id="credits">
        <p>Créé par Varjavandi Thomas, Brisé Mathéo et Guioochet Titouan</p>
    </div>
</footer>
<!-- Fin footer -->