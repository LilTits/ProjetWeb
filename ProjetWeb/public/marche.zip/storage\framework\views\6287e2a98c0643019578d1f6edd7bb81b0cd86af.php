<?php $__env->startSection('content'); ?>

    <div>
        <h1>Ca marche</h1>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>