<?php $__env->startSection('content'); ?>

<?php if(auth()->guard()->check()): ?>
<!-- Start of comment section -->
<section id="comment">
    <div class="comment_section container">
        <div class="row">
            <?php if(count($comments) > 0): ?>
            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-12 card frame_comment">
                <div class="card-body">
                    <p class="card-text"><?php echo e($comment->description); ?></p>
                    <br>
                    <small>Ajouté le <?php echo e($comment->created_at); ?> by <?php echo e($comment->user->first_name); ?> <?php echo e($comment->user->last_name); ?> </small>
                </div>
                <a href="/comments/<?php echo e($comment->id); ?>edit" class="btn btn-primary">Edition</a>
                <?php echo Form::open(['action' => ['CommentsController@destroy', $comment->id], 'method' => 'POST']); ?>

                    <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                    <?php echo e(Form::submit('Suppression', ['class' => 'btn btn-danger'])); ?>

                <?php echo Form::close(); ?>

            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <p>Pas de commentaire</p>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php endif; ?>
<?php if(auth()->guard()->guest()): ?>

<div class="d-flex justify-content-center"><?php echo $__env->make('auth.login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></div>
<?php endif; ?>
<!-- End of comment section -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>