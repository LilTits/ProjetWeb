<?php $__env->startSection('content'); ?>
<!-- Start of comment section -->
<?php if(auth()->guard()->check()): ?> <!--If auth-->
<section id="comment">
    <div class="comment_section container">
        <h3>Commentaire</h3>
        <div class="row">
            <div class="col-12">
                <?php echo Form::open(['action' => 'CommentsController@store', 'method' => 'POST']); ?>

                    <div class="form-group">
                        <?php echo e(Form::label('description', 'Description')); ?>

                        <?php echo e(Form::textarea('description', '', [
                        'class' => 'form-control',
                        'placeholder' => 'Votre commentaire'
                    ])); ?>

                    </div>
                    <?php echo e(Form::submit('Submit', ['class' => 'btn btn-primary'])); ?>

                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
</section>
<?php endif; ?>
<?php if(auth()->guard()->guest()): ?>

<div class="d-flex justify-content-center"><?php echo $__env->make('auth.login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></div>
<?php endif; ?>
<!-- End of comment section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>