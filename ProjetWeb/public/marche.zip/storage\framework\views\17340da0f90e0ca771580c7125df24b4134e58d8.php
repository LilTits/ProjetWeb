<?php $__env->startSection('content'); ?>
<!-- Start of comment section -->
<section id="comment">
    <div class="comment_section container">
        <a href="/comments" class="btn btn-default">Retour en arrière</a>
        <div class="col-12 item_comment">
            <small class="card-body">
                <p class="card-text"><?php echo e($comment->description); ?></p>
            </small>
        </div>
        <hr>
        <small>Ajouté le <?php echo e($comment->created_at); ?> by <?php echo e($comment->author); ?> </small>
        <hr>
        <a href="/comments/<?php echo e($comment->id); ?>/edit" class="btn">Edition</a>
        <?php echo Form::open(['action' => ['CommentsController@destroy', $comment->id], 'method' => 'POST']); ?>

            <?php echo e(Form::hidden('_method', 'DELETE')); ?>

            <?php echo e(Form::submit('Suppression', ['class' => 'btn btn-danger'])); ?>

        <?php echo Form::close(); ?>

    </div>
</section>
<!-- End of comment section -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>