<?php $__env->startSection('content'); ?>
<?php if(auth()->guard()->check()): ?>
<!-- Start of product section -->
<section id="product">
    <div class="product_section container">
        <h3 class="title_section">Edition de Produits</h3>
        <div class="row">
            <div class="col-12">
                <?php echo Form::open(['action' => ['ProductTypesController@update', $product->id], 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

                    <div class="form-group">
                        <?php echo e(Form::label('name', 'Nom')); ?>

                        <?php echo e(Form::text('name', $product->name, [
                        'class' => 'form-control',
                        'placeholder' => 'Nom du produit'])); ?>

                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('description', 'Description')); ?>

                        <?php echo e(Form::textarea('description', $product->description, [
                        'class' => 'form-control',
                        'placeholder' => 'Description du produit'
                    ])); ?>

                    </div>
                    <div class="form-group">
                    <?php echo e(Form::label('categorie', 'Categorie')); ?>

                    <?php echo e(Form::select('pcategory_id',["1"=>"Pas de catégorie", "2"=>"Vêtements","3"=>"Bibelots","4"=>"Services","5"=>"Tasses et tapis","6"=>"Apple de Titou","7"=>"Les poules de Mathéo","8"=>"Pantoufle et chaussettes"],$product->pcategory_id, [
                    'class' => 'form-control',
                ])); ?>

                </div>
                    <div class="form-group">
                        <?php echo e(Form::label('price', 'Prix')); ?>

                        <?php echo e(Form::number('price', $product->price, [ 'class' => 'form-control' ])); ?>

                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('stock', 'Quantité restante')); ?>

                        <?php echo e(Form::number('stock', $product->stock, [ 'class' => 'form-control' ])); ?>

                    </div>
                    <div class="form-group">
                        <?php echo e(Form::file('product_image')); ?>

                    </div>
                    <?php echo e(Form::hidden('_method', 'PUT')); ?>

                    <?php echo e(Form::submit('Submit', ['class' => 'btn btn-primary'])); ?>

                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
</section>
<?php endif; ?>
<?php if(auth()->guard()->guest()): ?>

<div class="d-flex justify-content-center"><?php echo $__env->make('auth.login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></div>
<?php endif; ?>
<!-- End of product section -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>