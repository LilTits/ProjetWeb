<?php $__env->startSection('content'); ?>
<!-- Start of product section -->
<section id="product">
    <div class="product_section container">
        <h3 class="title_section">Produits</h3>
        <div class="row">
            <?php if(count($products) > 0): ?>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-xs-12 col-sm-6 col-lg-4 item_product">
                <div class="col-12 card frame_product">
                    <img src="/storage/products/<?php echo e($product->product_image); ?>"
                        class="card-img-top img-thumbnail image_product" alt="Product">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($product->name); ?></h5>
                        <p class="card-text"><?php echo e($product->category->name); ?></p>
                        <p class="card-text"><?php echo e($product->price); ?></p>
                        <a href="/products/<?php echo e($product->id); ?>" class="btn btn-primary buy_button_product">En savoir plus</a>
                        <?php echo e(-- <?php echo Form::open(['action' => 'CartsController@store', 'method' => 'POST']); ?>

                        <div class="form-group">
                            {{Form::hidden('id', $product->id)); ?>

                            <?php echo e(Form::hidden('name', $product->name)); ?>

                            <?php echo e(Form::hidden('price', $product->price)); ?>

                            <?php echo e(Form::hidden('product_image', $product->product_image)); ?>

                        </div>
                        <?php if(auth()->guard()->check()): ?>                                <!--Only auth-->
                        <?php echo e(Form::submit('Ajoutez au panier', ['class' => 'btn btn-primary'])); ?>

                        <?php echo Form::close(); ?>

                        <?php endif; ?>
                        <br>
                        <small>Ajouté le <?php echo e($product->created_at); ?></small>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <p>Pas de produits</p>
            <?php endif; ?>
        </div>
    </div>
</section>
<!-- End of product section -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>