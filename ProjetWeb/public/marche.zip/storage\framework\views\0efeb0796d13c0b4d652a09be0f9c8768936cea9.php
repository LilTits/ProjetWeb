
<section id="bde">
    <div class="jumbotron">
        <div class="container welcome_index">
        <a button class="btn btn-primary btn-lg btn btn-dark" href="/products/create">Créer un produit</a>
        <a button class="btn btn-primary btn-lg btn btn-dark" href="/events/create">Créer un event</a>
        <a button class="btn btn-primary btn-lg btn btn-dark" href="/ideas/create">Créer une idée</a>
        <a button class="btn btn-primary btn-lg btn btn-dark" href="/comments/create">Créer un commentaire</a>
        <a button class="btn btn-primary btn-lg btn-warning"  href="/emails">Envoyer un mail</a>
        <a button class="btn btn-primary btn-lg btn btn-dark" href="/downloadsf">Télécharger les images</a>
        <a href="<?php echo e(asset('events/')); ?>" download='therock.jpg'>
              <button type="button" class="btn btn-danger">Télécharger</button>
              </a>
        </div>
    </div>
</section>




      