
<!-- Start of event section -->
<section id="user">
    <div class="user_section container">
        <h3 class="title_section">Evènements</h3>
        <div class="row">
        <div class="table-responsive">
            <table class="table table-dark text-white">
                <thead>
                    <tr>
                        <th scope="col"><?php echo app('translator')->getFromJson('Nom'); ?></th>
                        <th scope="col"><?php echo app('translator')->getFromJson('Email'); ?></th>
                        <th scope="col"><?php echo app('translator')->getFromJson('Inscription'); ?></th>
                        <th scope="col"><?php echo app('translator')->getFromJson('Vérifié'); ?></th>
                        <th scope="col"><?php echo app('translator')->getFromJson('Adulte'); ?></th>
                        <th scope="col"><?php echo app('translator')->getFromJson('Photos'); ?></th>
                        <th></th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>

            <?php if(count($users) > 0): ?>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <!-- <div class="col-12 card frame_event"> -->
                <!-- <div class="card-body"> -->
                    <!-- <h5 class="card-title"><?php echo e($user->first_name); ?></h5> -->
                    <!-- <h6 class="price"><?php echo e($user->last_name); ?></h6> -->
                    <!-- <p class="card-text"><?php echo e($user->role_id); ?></p> -->
                    <!-- <p class="card-text">Nombre de participants : <?php echo e($user->center_id); ?></p> -->
                    <!-- <p class="card-text">Débute le : <?php echo e($user->first_name); ?></p> -->
                          
                <!-- </div> -->
            <!-- </div> -->

            <tr <?php if($user->admin): ?> style="color: red" <?php endif; ?>>
                        <td><?php echo e($user->first_name); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php if($user->role_id): ?><i class="fas fa-check fa-lg"></i><?php endif; ?></td>
                        <td><?php echo e($user->images_count); ?></td>
                        <td>
                            <a type="button" 
                               class="btn btn-warning btn-sm pull-right mr-2 invisible" data-toggle="tooltip"
                               title="<?php echo app('translator')->getFromJson("Modifier l'utilisateur"); ?> <?php echo e($user->name); ?>"><i
                                        class="fas fa-edit fa-lg"></i></a>
                        </td>
                        <td>
                            <?php if (! ($user->admin)): ?>
                            <a type="button"
                               class="btn btn-danger btn-sm pull-right invisible" data-toggle="tooltip"
                               title="<?php echo app('translator')->getFromJson("Supprimer l'utilisateur"); ?> <?php echo e($user->name); ?>"><i
                                        class="fas fa-trash fa-lg"></i></a>
                            <?php endif; ?>
                        </td>
                    </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            </table>
        </div>
            <?php else: ?>
            <p>Pas d'evènement</p>
            <?php endif; ?>
        </div>
    </div>
</section>


<!-- End of event section -->
