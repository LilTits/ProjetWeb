<?php if(auth()->guard()->check()): ?>


<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-center">
  <div class="card" style="width: 18rem;">
    <img src="storage/<?php echo e(Auth::user()->profile->image_path); ?>" class="card-img-top" alt="">
    <div class="card-body">
      <h5 class="card-title"><?php echo e(Auth::user()->first_name); ?></br><?php echo e(Auth::user()->last_name); ?></h5>
      <p class="card-text"></p>
    </div>
    <ul class="list-group list-group-flush">
      <li class="list-group-item"><?php echo e(Auth::user()->email); ?></li>
      <li class="list-group-item">Votre solde : <?php echo e(Auth::user()->wallet_amount); ?> €</li>
      <li class="list-group-item">Votre campus : <?php echo e(Auth::user()->centers->name); ?></li>
      <li class="list-group-item">Votre role : <?php echo e(Auth::user()->roles->name); ?></li>
    </ul>
    <div class="card-body">
      <a href="#" class="card-link">Card link</a>
      <a href="#" class="card-link">Another link</a>
    </div>
  </div>
</div>
<!--If admin-->

<?php if(Auth::user()->role_id == 2): ?>
<?php echo $__env->make('perso.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endif; ?>

<?php if(Auth::user()->role_id == 3): ?>
<?php echo $__env->make('perso.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endif; ?>

<?php if(Auth::user()->role_id == 4): ?>
<?php echo $__env->make('perso.bde', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endif; ?>

<?php if(Auth::user()->role_id == 5): ?>
<?php echo $__env->make('perso.cesi', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endif; ?>


<?php $__env->stopSection(); ?>

<?php endif; ?>


<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>