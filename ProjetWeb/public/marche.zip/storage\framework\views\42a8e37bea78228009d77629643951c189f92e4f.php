<?php $__env->startSection('content'); ?>
<!-- Start of idea section -->
<section id="idea">
    <div class="idea_section container">
        <h3 class="title_section">Idée</h3>
        <div class="row">
            <?php if(count($ideas) > 0): ?>
            <?php $__currentLoopData = $ideas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-xs-12 col-sm-6 col-lg-4 item_idea">
                <div class="col-12 card frame_idea">
                    <img src="iphonex.png" class="card-img-top img-thumbnail image_idea" alt="Idea">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($idea->title); ?></h5>
                        <p class="card-text"><?php echo e($idea->description); ?></p>
                        <a href="/ideas/<?php echo e($idea->idea_id); ?>" class="btn btn-primary buy_button_idea">En savoir plus</a>
                        <br>
                        <small>Ajouté le <?php echo e($idea->created_at); ?></small>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <p>Pas de produits</p>
            <?php endif; ?>
        </div>
    </div>
</section>
<!-- End of idea section -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>