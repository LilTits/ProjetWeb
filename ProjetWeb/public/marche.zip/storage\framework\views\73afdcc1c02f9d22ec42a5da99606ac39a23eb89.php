<section id="bde">
    <div class="jumbotron">
        <div class="container welcome_index">
                   <a button class="btn btn-primary btn-lg"  href="/emails">Envoyer un mail aux membres du BDE</a>
        
     
        </div>
    </div>
    
</section>