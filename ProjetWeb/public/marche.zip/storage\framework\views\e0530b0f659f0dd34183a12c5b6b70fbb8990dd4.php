<?php $__env->startSection('content'); ?>
<?php if(auth()->guard()->check()): ?>
<section id="basket" class="container">
    <div class="row">
        <div class="col-12">
            <h2>Panier</h2>
        </div>
        <?php if(count($cart) > 0): ?>
        <div class="col-sm-6 col-md-6">
            
            <div class="row">
                <ul class="list-group">
                    <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($product->user_id == auth()->user()->id): ?>
                    <li class="list-group-item">
                        <div class="card mb-3"">
                            <div class=" row no-gutters">
                                <div class="col-6">
                                    <h5 class="card-title"><?php echo e($product->id); ?></h5>
                                </div>
                                <div class="col-6">
                                    <p class="card-text"><small><?php echo e($product->price); ?> €</small></p>
                                </div>
                                <div class="col-md-12 btn-group">
                                    <a href="/products/<?php echo e($product->id); ?>" class="btn btn-primary">Retournez sur la page du produit</a>
                                    <?php echo Form::open(['action' => ['CartsController@destroy', $product->rowId], 'method' =>
                                    'POST']); ?>

                                    <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                                    <?php echo e(Form::submit('Suppression', ['class' => 'btn btn-danger'])); ?>

                                    <?php echo Form::close(); ?>

                                </div>
                            </div>
                        </div>
                    </li>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    <div class="col-12">
        <hr>
        <p>Prix HT : <?php echo e(Cart::subtotal()); ?> €</p>
        <br>
        <p>Taxe : <?php echo e(Cart::tax()); ?> €</p>
        <br>
        <span>Prix TTC : <?php echo e(Cart::total()); ?> €</span>
    </div>

    
    
    <?php else: ?>
    <div class="col-sm-6 col-md-6">
        <h3>Pas de produit dans le panier</h3>
        <a href="/products">Retournez sur la Boutique</a>
    </div>
    <?php endif; ?>
    </div>

</section>
<?php endif; ?>

<?php if(auth()->guard()->guest()): ?>

<div class="d-flex justify-content-center"><?php echo $__env->make('auth.login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>