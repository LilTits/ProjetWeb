<section id="bde">
    <div class="jumbotron">
        <div class="container welcome_index">
            
        <a button class="btn btn-primary btn-lg" href="/products/create">Créer un produit</a>
        <a button class="btn btn-primary btn-lg" href="/events/create">Créer un event</a>
        <a button class="btn btn-primary btn-lg" href="/ideas/create">Créer une idée</a>
        <a button class="btn btn-primary btn-lg" href="/comments/create">Créer un commentaire</a>
        
        
     
        </div>
    </div>
    
</section>

