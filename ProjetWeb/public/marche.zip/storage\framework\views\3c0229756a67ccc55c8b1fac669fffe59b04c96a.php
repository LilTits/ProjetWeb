<?php $__env->startSection('content'); ?>
<!-- Start of product section -->
<?php if(auth()->guard()->check()): ?> <!--If auth-->
<section id="product">
    <div class="product_section container">
        <h3 class="title_section">Création de Produits</h3>
        <div class="row">
            <div class="col-12">
                <?php echo Form::open(['action' => 'ProductTypesController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

                <div class="form-group">
                    <?php echo e(Form::label('name', 'Nom')); ?>

                    <?php echo e(Form::text('name', '', [
                    'class' => 'form-control',
                    'placeholder' => 'Nom du produit'])); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('description', 'Description')); ?>

                    <?php echo e(Form::textarea('description', '', [
                    'class' => 'form-control',
                    'placeholder' => 'Description du produit'
                ])); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('categorie', 'Categorie')); ?>

                    <?php echo e(Form::select('pcategory_id',["1"=>"Pas de catégorie", "2"=>"Vêtements","3"=>"Bibelots","4"=>"Services","5"=>"Tasses et tapis","6"=>"Apple de Titou","7"=>"Les poules de Mathéo","8"=>"Pantoufle et chaussettes"],"", [
                    'class' => 'form-control',
                ])); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('price', 'Prix')); ?>

                    <?php echo e(Form::number('price', '', [ 'class' => 'form-control' ])); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('stock', 'Quantité restante')); ?>

                    <?php echo e(Form::number('stock', '', [ 'class' => 'form-control' ])); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::file('product_image')); ?>

                </div>
                <?php echo e(Form::submit('Submit', ['class' => 'btn btn-primary'])); ?>

            <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
</section>
<?php endif; ?>
<?php if(auth()->guard()->guest()): ?>

<div class="d-flex justify-content-center"><?php echo $__env->make('auth.login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></div>
<?php endif; ?>
<!-- End of product section -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>