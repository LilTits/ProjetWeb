<?php $__env->startSection('content'); ?>

<section id="basket" class="container">
    <?php if(Session::has('cart')): ?>
    <div class="row">
        <div class="col-sm-6 col-md-6">
            <ul class="list-group">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item">
                    <span class="badge"><?php echo e($product['qty']); ?></span>
                    <h5><?php echo e($product['item']['title']); ?></h5>
                    <span class="label label-sucess"><?php echo e($product['price']); ?></span>
                    <div class="btn-group">
                        <button class="btn btn-primary dropdown-toggle" data-toggle="dropdown">Action <span
                                class="caret"></span>
                            <ul class="dropdown-menu">
                                <li><a href="#">Supprimez 1 produit</a></li>
                                <li><a href="#">Supprimez tous les produits</a></li>
                            </ul>
                        </button>
                    </div>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <div class="col-sm-6 col-md-6">
            <p>Total : <?php echo e($totalPrice); ?> </p>
        </div>
        <div class="col-sm-6 col-md-6">
            <button class="btn btn-success">Commander</button>
        </div>
    </div>
    <?php else: ?>
    <div class="col-sm-6 col-md-6">
        <p>No Items</p>
    </div>
    <?php endif; ?>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>