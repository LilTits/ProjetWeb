<?php $__env->startSection('content'); ?>
<!-- Start of event section -->
<section id="event">
    <div class="event_section container">
        <h3 class="title_section">Evènements</h3>
        <div class="row">
            <?php if(count($events) > 0): ?>
            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-12 card frame_event">
                <img src="/storage/events/<?php echo e($event->event_image); ?>" class="card-img-top img-thumbnail image_event" alt="event">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($event->name); ?></h5>
                    <h6 class="price"><?php echo e($event->price); ?></h6>
                    <p class="card-text"><?php echo e($event->description); ?></p>
                    <p class="card-text">Nombre de participants : <?php echo e($event->max_participants); ?></p>
                    <p class="card-text">Débute le : <?php echo e($event->start_date); ?></p>
                    
                    <a href="/events/<?php echo e($event->id); ?>" class="btn btn-primary buy_button_event">En savoir plus</a>
                    <a href="" class="btn btn-primary buy_button_event">S'inscrire</a>
                    <hr>

                    <small>Ajouté le <?php echo e($event->created_at); ?> by <?php echo e($event->eventCreator->first_name); ?>

                        <?php echo e($event->eventCreator->last_name); ?></small>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <p>Pas d'evènement</p>
            <?php endif; ?>
        </div>
    </div>
</section>
<!-- End of event section -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>